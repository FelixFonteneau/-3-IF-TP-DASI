/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import com.google.maps.model.LatLng;
import util.GeoTest;
import dao.EmployeDAO;
import dao.JpaUtil;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import metier.modele.*;
import metier.service.*;
import util.DebugLogger;
import static util.GeoTest.getFlightDistanceInKm;
import static util.GeoTest.getLatLng;
import static util.GeoTest.getTripDistanceByCarInKm;
import static util.GeoTest.getTripDurationByBicycleInMinute;
import util.Message;

/**
 *
 * @author Quentin Ferro
 */
public class Main {
    
    public static void main(String[] args) {
        
        //exemple d'utilisation des méthodes de la couche service
        JpaUtil.init();
        
        //initialisation des employes dans la base
        EmployeDAO.initBase();
        
        //ajout de quelques clients dans la base
        Date d = new Date(1998, 9, 2);
        Client salut = new Client("Ferro", "BG", d, "CHOSE", "0668629985", "mao.zedong@insa-lyon.fr", "221 Boulevard Adrian, Saint-Raphael", "mdp");
        Client salut2 = new Client("Lechat", "Felix", d, "CHOSE", "0609837263", "lenine@insa-lyon.fr", "Rue de la République, Lyon", "mdp");
        Service.inscription(salut);
        Service.inscription(salut2);
        
        
        //authentification client
        Service.authentification("mao.zedong@insa-lyon.fr", "mdp");
        Personne p = Service.authentification("mao.zedong@insa-lyon.fr", "hmmm");
        Service.authentification("bah", "mdp");   

        //authentification employe
        Employe emp = (Employe) Service.authentification( "vladimir.poutine@insa-lyon.fr",  "mdp");
        
        //ajout d'intervention à la base
        InterventionAnimale interMilan = new InterventionAnimale(salut, new Date(), "blabla", "Chat" ,"test");
        InterventionAnimale inter2 = new InterventionAnimale(salut2, new Date(), "miaou", "Chat" ,"test");
        System.out.println("====="+interMilan.getClass().getName());
        Service.demandeInter(interMilan);
        Service.demandeInter(inter2);
        
        //liste de l'historique du client
        List<Intervention> historique = Service.historiqueClient(salut);
        for(Intervention i : historique){
            System.out.println("   "+i.getDescription());
        }
        
        //cloture d'une intervention
        Service.cloturerIntervention(emp, "c'était très bien", "Terminéee");
        
        //historique des intervention de la journées 
        List<Intervention> historique2 = Service.interventionsJournee();
        for(Intervention i : historique2){
            System.out.println("   "+i.getDescription());
        }
        
        
        JpaUtil.destroy();
    }
}
